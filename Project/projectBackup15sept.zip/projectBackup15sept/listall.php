<html>
 <head>
 <script src="text.js"></script>
 <LINK rel="stylesheet" type="text/css" href="style.css">
  <title>All Available Books</title>
 </head>
 <body>
<div class="home img">
 <a href="index.html">
 <img border="0" align="left" alt="Let`s Go Home Page!" src="homebutton1.jpg" width="60" height="55"> </a> 
 </div>
<div class="sign img">
 <a href="signup.html">
<img border="0" align="right" alt="Sign IN" src="signup.jpg" width="75" height="30"> </a>
 </div>
 <div class="sign img">
 <a href="signin.html">
<img border="0" align="right" alt="Sign UP" src="Untitled1.gif" width="75" height="30"> </a>
 </div>
 <center><h2> Available Books</h2></center>
<center>
 <form action="searchbook.php" method="post">
<p2><b>Search: </b></p2> 
<input type="text" name="search" size="100" value="" placeholder="Search Books by Book ID or Book Name or Author or Department...">
<br><br>
<input type="submit" value="Let`s Search">
</form>
<b><i><p3> Registering your taken Books is Easier than ever,Type Username and Password & Select any 3 books >>>Get Books! </p3></i></b><br>
<fieldset>
 <?php
        //connect to DB
 $con=mysqli_connect("localhost","root","zxcvbnm" ,"test") or die("OOPS!!!Error In Connection! Thats all we know!".mysqli_error()) ;
// $db_found = mysqli_select_db("test");
$link="getthisbook.html";
$result = mysqli_query($con,"SELECT *FROM books");
echo "<p1><b><i>List of Books in The Library</i></b></p1><br>";
echo "<form action='getbook.php' method='POST' onSubmit='return validate()'>";
echo "<b><i><p3>Username :</p3></i> <input type='text' name='uname' value='' placeholder='Enter your Username...' required/>&nbsp"; 
echo "<b><i><p3>Password :</p3></i> <input type='password' name='pwd' value='' placeholder='Enter your Password...' required/><br>&nbsp"; 
echo "<table border='1'>
<tr>
<th>Book ID</th>
<th>Department</th>
<th>Book Name</th>
<th>Author</th>
<th>Total Books</th>
<th>Taken Books </th>
<th>Available Now </th>
</tr>";

while($row = mysqli_fetch_array($result))
  {
  $bookid=$row['bookid'];	  
  $bookname=$row['bname'];
  echo "<tr>";
  echo "<td>";
  echo "<input type='checkbox' name='chk[]' id='3' value=".$bookid.">" .$row['bookid']. "</td>";
  echo "<td>" . $row['department'] . "</td>";
  echo "<td>";
  echo "<input type='checkbox' name='bname[]' value=".$bookname." checked='true' style='display:none;'>" .$row['bname']. "</td>";
  echo "<td>" . $row['author'] . "</td>";
  echo "<td>" . $row['total'] . "</td>";
  echo "<td>" . $row['Takenbook'] . "</td>";
  echo "<td>" . $row['a_books'] . "</td>";
/*  echo "<td>";
  echo "<a href=".$link.">";
  echo "Get This Book </a>";
  echo"</td>"; */
  echo "</tr>";
  }
    echo "</table></center>";
    echo "<center><input type='SUBMIT' name='Submit' value='Get Books'></center>";
 echo "</form>" ;	
  mysqli_close($con);
?>
 </fieldset>
 </center>
  </body>
</html>
