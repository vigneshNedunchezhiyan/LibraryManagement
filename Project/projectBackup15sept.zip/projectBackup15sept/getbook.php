<html>
<head>
<LINK rel="stylesheet" type="text/css" href="style.css">
<title>Get Books </title>
</head>
<body>
<div class="home img">
 <a href="index.html">
 <img border="0" align="left" alt="Let`s Go Home Page!" src="homebutton1.jpg" width="60" height="55"> </a> 
 </div>
 <div class="home img">
 <a href="search.html">
 <img border="0" align="left" alt="Let`s Search!" src="search.jpg" width="60" height="55"> </a> 
 </div>
<div class="sign img">
 <a href="signin.html">
 <img border="0" align="right" alt="Sign IN!" src="untitled1.gif" width="60" height="55"> </a> 
 </div> <br> 
 <center>
<?php

$myusername=$_POST['uname'];
$mypassword=$_POST['pwd'];
$book=$_POST['chk'];
$bookname=$_POST['bname'];
$sql="SELECT * FROM student WHERE username='$myusername' AND pwd='$mypassword'";
$con=mysqli_connect("localhost","root","zxcvbnm" ,"test") or die("OOPS!!!Error In Connection! Thats all we know!".mysqli_error());
$result=mysqli_query($con,$sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);
if($count==1)
{
if (isset($book))
{
for ($i=0;$i<sizeof($book);$i++)
{
//Updates Books TABLE for Total, Available Books, Takenbook	
$q1="UPDATE `books` SET `Takenbook`=`Takenbook`+1 WHERE `bookid`='$book[$i]'";
$q2="UPDATE `books` SET `a_books`=`a_books`-1 where `bookid`='$book[$i]'";
$q3="UPDATE `books` SET `Total`=`Takenbook`+`a_books` where `bookid`='$book[$i]'";
//Updates Takenbook TABLE to INSERT books Taken by Users
$q4="INSERT INTO `takenbook`(`bookid`, `takenbook`, `username`) VALUES ('$book[$i]','$bookname[$i]','$myusername')";
mysqli_query($con,$q1)or die("Error in sql".mysqli_error());	
mysqli_query($con,$q2)or die("Error in sql".mysqli_error());	
mysqli_query($con,$q3)or die("Error in sql".mysqli_error());	
mysqli_query($con,$q4)or die("Error in sql".mysqli_error());
}
echo "<b><i><h3>Get Books Updated...</h3></i></b>";
}
else 
{ echo "<b> Error in html</b>"; }
}
else 
{
	
	echo "Incorrect Username OR Password! Try Again!";
}
?>
</center>
</body>
</html>