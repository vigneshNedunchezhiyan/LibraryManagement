<html>
<head>
<script src="text.js"></script>
 <LINK rel="stylesheet" type="text/css" href="style.css">
  <title>User Page</title>
 </head>
<body>
<div class="home img">
 <a href="index.html">
 <img border="0" align="left" alt="Let`s Go Home Page!" src="homebutton1.jpg" width="60" height="55"> </a> 
 </div>
<center>
 <fieldset>
 <?php
session_start();
$myusername=$_POST['uname'];
$mypassword=$_POST['pwd'];
//if(!$_session_is_registered ['uname']){
//header("location:signin.html");
//}
//else
//{
	echo "<b><p1>Login Successful</b></p1><br>";
	
//}
$con=mysqli_connect("localhost","root","zxcvbnm" ,"test") or die("OOPS!!!Error In Connection! Thats all we know!".mysqli_error()) ;
// $db_found = mysqli_select_db("test");
//$link="getthisbook.html";
$result = mysqli_query($con,"SELECT `userid`,`username`,`takenbook1`,`takenbook2`,`takenbook3` FROM `student` WHERE `username`='$myusername' AND `pwd`='$mypassword'");
echo "<p3><b><i>List of Books in The Library</i></b></h3>";
echo "<form action='returnbook.php' method='POST'>";
echo "<table border='1'>
<tr>
<th>ID</th>
<th>Book Name</th>
<th>Author</th>
<th>Total Books</th>
<th>Taken Books </th>
<th>Available Now </th>
</tr>";

while($row = mysqli_fetch_array($result))
  {
  $bookid=$row['bookid'];	  
  echo "<tr>";
  echo "<td>";
  echo "<input type='checkbox' name='chk[]' value=".$bookid.">" .$row['bookid']. "</td>";
  echo "<td>" . $row['bname'] . "</td>";
  echo "<td>" . $row['author'] . "</td>";
  echo "<td>" . $row['total'] . "</td>";
  echo "<td>" . $row['Takenbook'] . "</td>";
  echo "<td>" . $row['a_books'] . "</td>";
   echo "</tr>";
  }
  echo "</table></center>";
    echo "<center><input type='SUBMIT' name='Submit' value='Get Books'></center>";
 echo "</form>" ;
   mysqli_close($con);
?>
</fieldset>
 </center>
</body>
</html>