<html>
 <head>
 <script src="text.js"></script>
 <LINK rel="stylesheet" type="text/css" href="style.css">
  <title>Sign UP!</title>
 </head>
 <body>
 <div class="home img">
 <a href="index.html">
 <img border="0" align="left" alt="Let`s Go Home Page!" src="homebutton1.jpg" width="60" height="55"> </a> 
 </div>
 <div class="home img">
 <a href="search.html">
<img border="0" align="right" alt="Search the Library" src="search.jpg" width="75" height="30"> </a>
 </div>
 <center><h2>Account Confirmation! </h2></center>
<center>
<fieldset>
 <?php
        //connect to DB
 $con=mysqli_connect("localhost","root","zxcvbnm" ,"test") or die("OOPS!!!Error In Connection! Thats all we know!".mysqli_error());
// $db_found = mysqli_select_db("test");
$link="signup.html";
$uname=$_POST['uname'];
$pwd=$_POST['pwd'];
$mobile=$_POST['ph'];
$result = mysqli_query($con,"INSERT INTO `student` (`userid`, `username`, `pwd` ,`mobile`) VALUES (NULL, '$uname', '$pwd' ,'$mobile')");
if(!$result)
{
echo "<b>Username already exists!</b><a href='$link'> Try Again with some unique username!> </b></a>";
}
else 
{
	echo "<h3><b>Congrats!You`re now a Member of this Library</b></h3>";
	echo "<br><div class='sign img'>";
 echo "<a href='signin.html'>";
echo "<img border='0' align='center' alt='Sign IN' src='Untitled1.gif' width='75' height='30'> </a>";
 echo "</div>";
}
   mysqli_close($con);
?>
 </fieldset>
 </center></body>
</html>

