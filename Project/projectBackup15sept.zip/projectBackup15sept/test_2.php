 <html>
<head>
<title>SignIN</title>
</head>
<body>
<form>
<center>
<?php
echo "Testing.........";
$servername = "localhost";
$username = "username";
$password = "password";
<h6><b>THIS IS A PHP TEST PAGE!!! </h6> </b>
<br>
<b>Username </b>: <input type="text" value="" Placeholder="Enter Username..." id="un"/> <br>
<button onClick="testunpwd();">SignIN</Button>
<center>
</form id="">
<br><br><br>
<br><br><br>
<script type="text/JS">
function testunpwd()
{
var uname=document.getElementById("un").value;
if(uname.value=="")
{ alert("Username Empty");
uname.focus();
 }
else
{

}
document.write("This is a Java Script test!");
}
</script>
</body>
</html>
// Create connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";
?>
</body>
</hrml>