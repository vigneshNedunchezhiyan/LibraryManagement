<?php

/*** begin our session ***/
session_start();

/*** check if the users is already logged in ***/
if(isset( $_SESSION['userid'] ))
{
    $message = 'Users is already logged in';
}
/*** check that both the username, password have been submitted ***/
if(!isset( $_POST['uname'], $_POST['pwd']))
{
    $message = 'Please enter a valid username and password';
}
/*** check the username is the correct length ***/
elseif (strlen( $_POST['uname']) > 20 || strlen($_POST['uname']) < 4)
{
    $message = 'Incorrect Length for Username';
}
/*** check the password is the correct length ***/
elseif (strlen( $_POST['pwd']) > 20 || strlen($_POST['pwd']) < 4)
{
    $message = 'Incorrect Length for Password';
}
else
{
    /*** if we are here the data is valid and we can insert it into database ***/
    $uname = filter_var($_POST['uname'], FILTER_SANITIZE_STRING);
    $pwd = filter_var($_POST['pwd'], FILTER_SANITIZE_STRING);

    /*** now we can encrypt the password ***/
    $pwd = sha1( $pwd );
    
    /*** connect to database ***/
    /*** mysql hostname ***/
    $mysql_hostname = 'localhost';

    /*** mysql username ***/
    $mysql_username = 'root';

    /*** mysql password ***/
    $mysql_password = 'zxcvbnm';

    /*** database name ***/
    $mysql_dbname = 'test';

    try
    {
        $dbh = new PDO("mysql:host=$mysql_hostname;dbname=$mysql_dbname", $mysql_username, $mysql_password);
        /*** $message = a message saying we have connected ***/

        /*** set the error mode to excptions ***/
        $dbh->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        /*** prepare the select statement ***/
        $stmt = $dbh->prepare("SELECT userid, uname, pwd FROM student WHERE uname = :uname AND pwd = :pwd");

        /*** bind the parameters ***/
        $stmt->bindParam(':uname', $uname, PDO::PARAM_STR,20);
        $stmt->bindParam(':pwd', $pwd, PDO::PARAM_STR, 20);

        /*** execute the prepared statement ***/
        $stmt->execute();

        /*** check for a result ***/
        $userid = $stmt->fetchColumn();

        /*** if we have no result then fail boat ***/
        if($userid == false)
        {
                $message = 'Login Failed';
        }
        /*** if we do have a result, all is well ***/
        else
        {
                /*** set the session userid variable ***/
                $_SESSION['userid'] = $userid;

                /*** tell the user we are logged in ***/
                $message = 'You are now logged in';
        }


    }
    catch(Exception $e)
    {
        /*** if we are here, something has gone wrong with the database ***/
        $message = 'We are unable to process your request. Please try again later"';
    }
}
?>

<html>
<head>
<title>Sign IN</title>
</head>
<body>
<p><?php echo $message; ?>
</body>
</html>