<?php
// Begin the session
session_start();

// Unset all of the session variables.
session_unset();

// Destroy the session.
session_destroy();
?>
<html>
<head>
<LINK rel="stylesheet" type="text/css" href="style.css">
<title>Logged Out</title>
</head>
<body>
<br>
<div class="home img">
 <a href="index.html">
 <img border="0" align="left" alt="Let`s Go Home Page!" src="homebutton1.jpg" width="60" height="55"> </a> 
 </div>
 <div class="home img">
 <a href="search.html">
 <img border="0" align="left" alt="Let`s Search!" src="search.jpg" width="60" height="55"> </a> 
 </div>
<div class="sign img">
 <a href="signup.html">
 <img border="0" align="right" alt="Sign UP!" src="signup.jpg" width="60" height="55"> </a> 
 </div> 
 <div class="sign img">
 <a href="signin.html">
 <img border="0" align="right" alt="Sign IN!" src="untitled1.gif" width="60" height="55"> </a> 
 </div> <br> 
<br><br>
<br>
 <center>
<style="font-size:25px;"><h3>You are now logged out. Please come again! </h3></style>
</center>
</body>
</htl>