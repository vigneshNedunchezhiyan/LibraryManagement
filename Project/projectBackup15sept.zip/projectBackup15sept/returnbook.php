<html>
<head>
<script src="text.js"></script>
<LINK rel="stylesheet" type="text/css" href="style.css">
<title>Get Books </title>
</head>
<body>
<div class="home img">
 <a href="index.html">
 <img border="0" align="left" alt="Let`s Go Home Page!" src="homebutton1.jpg" width="60" height="55"> </a> 
 </div>
 <div class="home img">
 <a href="search.html">
 <img border="0" align="left" alt="Let`s Search!" src="search.jpg" width="60" height="55"> </a> 
 </div>
<div class="sign img">
 <a href="signin.html">
 <img border="0" align="right" alt="Sign IN!" src="untitled1.gif" width="60" height="55"> </a> 
 </div> <br> 
 <center>
<?php
$username=$_POST['uname'];
$book=$_POST['chk'];

if (isset($book))
{
$con=mysqli_connect("localhost","root","zxcvbnm" ,"test") or die("OOPS!!!Error In Connection! Thats all we know!".mysqli_error());
for ($i=0;$i<sizeof($book);$i++)
{
$q1="UPDATE `books` SET `Takenbook`=`Takenbook`-1 WHERE `bookid`='$book[$i]'";
$q2="UPDATE `books` SET `a_books`=`a_books`+1 where `bookid`='$book[$i]'";
$q3="UPDATE `books` SET `Total`=`Takenbook`+`a_books` where `bookid`='$book[$i]'";
$q4="DELETE FROM `takenbook` WHERE `username` = '$username'";
mysqli_query($con,$q1)or die("Error in sql".mysqli_error());	
mysqli_query($con,$q2)or die("Error in sql".mysqli_error());	
mysqli_query($con,$q3)or die("Error in sql".mysqli_error());	
mysqli_query($con,$q4)or die("Error in sql".mysqli_error());	
}
echo "<b><i><h3>Return Books Updated... </h3></i></b>";
}
else 
{ echo "<b> Error in html</b>"; }
?>
</center>
</body>
</html>