<html>
<body>

<?php
echo "My first Sample PHP script!";
?>


</body>
</html>