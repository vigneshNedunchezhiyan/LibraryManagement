<html>
<head>
<script src="text.js"></script>
<LINK rel="stylesheet" type="text/css" href="style.css">
<title>User Page</title></head>
<body>
<div class="home img">
 <a href="index.html">
 <img border="0" align="left" alt="Let`s Go Home Page!" src="homebutton1.jpg" width="60" height="55"> </a> 
 </div>
 <div class="home img">
 <a href="search.html">
 <img border="0" align="left" alt="Let`s Search!" src="search.jpg" width="60" height="55"> </a> 
 </div> <br> 
<center>
<?php

ob_start();
/*$host="localhost"; // Host name
$username=""; // Mysql username
$password=""; // Mysql password
$db_name="test"; // Database name
$tbl_name="members"; // Table name
*/
// Connect to server and select databse.
$con=mysqli_connect("localhost", "root", "zxcvbnm","test")or die("cannot connect");
//mysql_select_db("$db_name")or die("cannot select DB");

// Define $myusername and $mypassword
$myusername=$_POST['uname'];
$mypassword=$_POST['pwd'];

// To protect MySQL injection (more detail about MySQL injection)
$myusername = stripslashes($myusername);
$mypassword = stripslashes($mypassword);
$myusername = mysqli_real_escape_string($con,$myusername);
$mypassword = mysqli_real_escape_string($con,$mypassword);

$sql="SELECT * FROM student WHERE username='$myusername' AND pwd='$mypassword'";
$result=mysqli_query($con,$sql);

// Mysql_num_row is counting table row
$count=mysqli_num_rows($result);

// If result matched $myusername and $mypassword, table row must be 1 row

if($count==1)
{
echo "<div class='sign img'>";
echo "<a href='signout.php'>";
echo "<img border='0' align='right' alt='Sign OUT' src='signout.jpg' width='75' height='30'> </a>";
 echo "</div>";

// Register $myusername, $mypassword and redirect to file "login_success.php"$_sesionstrar
//header("location:login_success.php");
session_start();
/*$myusername=$_POST['uname'];
$mypassword=$_POST['pwd'];
$_session['$myusername'];
$_session['$mypassword']; */
//if(!$_session_is_registered ['uname']){
//header("location:signin.html");
//}
//else
//{
	echo "<b><p1>Login Successful</b></p1><br>";
	echo "<h3>Hi,$myusername</h3>"; 
	
//}
//$con=mysqli_connect("localhost","root","zxcvbnm" ,"test") or die("OOPS!!!Error In Connection! Thats all we know!".mysqli_error()) ;
// $db_found = mysqli_select_db("test");
//$link="getthisbook.html";
$result1 = mysqli_query($con,"SELECT `bookid`,`takenbook` FROM `takenbook` WHERE `username`='$myusername'");
echo "<p3><b><i>Books taken in The Library</i></b></h3>";
echo "<fieldset>";
echo "<form action='returnbook.php' method='POST'>";
echo "<b><i>Username :</i> <input type='text' name='uname' value='' placeholder='Enter your Username...' required/>&nbsp"; 
echo "<table border='1'>
<tr>
<th>Book ID</th>
<th>Takenbook</th>
</tr>";

while($row = mysqli_fetch_array($result1))
  {
  $bookid=$row['bookid'];	  
  echo "<tr>";
  echo "<td>";
  echo "<input type='checkbox' name='chk[]' value=".$bookid.">" .$row['bookid']. "</td>";
  //echo "<td>" . $row['userid'] . "</td>";
  //echo "<td>" . $row['username'] . "</td>";
    echo "<td>" . $row['takenbook'] . "</td>";
    echo "</tr>";
  }
  echo "</table></center>";
    echo "<center><input type='SUBMIT' name='Submit' value='Return Books'></center>";
 echo "</form>" ;
 echo "</fieldset>";
   mysqli_close($con);
}
else {
echo "Wrong Username or Password";
}

ob_end_flush();
?></body>
</html>